-- Student Expenses: database schema for Supabase (Postgres)
-- Run in the Supabase SQL editor on a fresh project.

create extension if not exists pgcrypto;

create table public.households (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  invite_code varchar(12) not null unique,
  currency    varchar(3) not null default 'USD',
  created_by  text not null,
  created_at  timestamptz not null default now()
);

create table public.members (
  id           uuid primary key default gen_random_uuid(),
  household_id uuid not null references public.households(id) on delete cascade,
  user_id      text,                       -- null = placeholder (not joined yet)
  display_name text not null,
  role         text not null default 'member',  -- 'owner' | 'member'
  created_at   timestamptz not null default now()
);
create index on public.members (household_id);
create index on public.members (user_id);

create table public.expenses (
  id           uuid primary key default gen_random_uuid(),
  household_id uuid not null references public.households(id) on delete cascade,
  description  text not null,
  amount_cents integer not null check (amount_cents > 0),
  paid_by      uuid not null references public.members(id),
  split_type   text not null default 'equal',   -- 'equal' | 'custom'
  category     text not null default 'Other',
  spent_on     date not null,
  notes        text,
  created_by   text not null,
  created_at   timestamptz not null default now()
);
create index on public.expenses (household_id);

create table public.expense_shares (
  id           serial primary key,
  expense_id   uuid not null references public.expenses(id) on delete cascade,
  member_id    uuid not null references public.members(id),
  amount_cents integer not null check (amount_cents >= 0)
);
create index on public.expense_shares (expense_id);

create table public.payments (
  id           uuid primary key default gen_random_uuid(),
  household_id uuid not null references public.households(id) on delete cascade,
  from_member  uuid not null references public.members(id),
  to_member    uuid not null references public.members(id),
  amount_cents integer not null check (amount_cents > 0),
  note         text,
  paid_on      date not null,
  created_by   text not null,
  created_at   timestamptz not null default now()
);
create index on public.payments (household_id);

-- Privacy: all reads/writes go through the /api routes (service role), which
-- verify the user's session and household membership. Lock out direct access
-- with the public key entirely.
alter table public.households     enable row level security;
alter table public.members        enable row level security;
alter table public.expenses       enable row level security;
alter table public.expense_shares enable row level security;
alter table public.payments       enable row level security;

revoke all on public.households, public.members, public.expenses,
  public.expense_shares, public.payments from anon, authenticated;
revoke usage on sequence public.expense_shares_id_seq from anon, authenticated;
